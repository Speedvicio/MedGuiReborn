﻿Imports System.Threading
Imports System.Net
Imports System
Imports System.IO
Public Class Form1
    Dim cartella As String
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'chiude l'istanza di mednafen
        Dim myProcesses() As Process
        Dim myProcess As Process
        ' Restituisce un'array con tutti i processi chiamati MEdGuiR
        myProcesses = Process.GetProcessesByName("MedGuiR")
        'chiude ogni processo chiamato MEdGuiR
        For Each myProcess In myProcesses
            myProcess.Kill()
        Next

        Timer1.Enabled = True
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cartella = Application.StartupPath
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Public Sub elimino_temp()
        'Elimino il file locale e aggiornato 'temporaneo' al termine dell'update
        Try
            System.IO.Directory.Delete(cartella & "\MedGuiR\Update\", True)
        Catch
        End Try
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Try
            Dim infoReader As System.IO.FileInfo
            infoReader = My.Computer.FileSystem.GetFileInfo(cartella & "\MedGuiR\Update\MedGuiR.exe")

            If Dir(cartella & "\MedGuiR\Update\MedGuiR.exe") = "" Or infoReader.Length < 100 Then
                Timer1.Enabled = False
                MsgBox("No MedGui Reborn update found, please reupdate MedGui Reborn and try again.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Update error")

            Else
                Button1.Enabled = False
                Label1.Text = "Wait...."

                For Each foundFile As String In My.Computer.FileSystem.GetDirectories(cartella & "\MedGuiR\Update\", _
    FileIO.SearchOption.SearchAllSubDirectories, "*.*")

                    Dim foundFileInfo As New System.IO.FileInfo(foundFile)
                    My.Computer.FileSystem.MoveDirectory(foundFile, cartella & "\" & foundFileInfo.Name, True)
                Next

                If Dir(cartella & "\MedGuiR\Update\*.*") <> "" Then
                    For Each foundFile As String In My.Computer.FileSystem.GetFiles(cartella & "\MedGuiR\Update\", _
FileIO.SearchOption.SearchAllSubDirectories, "*.*")

                        Dim foundFileInfo As New System.IO.FileInfo(foundFile)
                        My.Computer.FileSystem.MoveFile(foundFile, cartella & "\" & foundFileInfo.Name, True)
                    Next
                End If
            End If

            elimino_temp()
            Process.Start(cartella & "\MedGuiR.exe")
            Me.Close()

        Catch
            elimino_temp()
            Process.Start(cartella & "\MedGuiR.exe")
        End Try
    End Sub
End Class
